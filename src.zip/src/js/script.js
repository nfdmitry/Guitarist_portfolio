document.querySelector('.mobile-menu').onclick = function() {
    document.querySelector('.mobile-menu').classList.toggle('active');
    document.querySelector('.nav-list').classList.toggle('active');
    document.querySelector('.navMobile').classList.toggle('openNav');
  };

